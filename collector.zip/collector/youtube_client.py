import os
import re
from datetime import datetime, timezone, timedelta
from typing import Iterator

import requests

API_KEY = os.environ.get("YOUTUBE_API_KEY", "")
BASE = "https://www.googleapis.com/youtube/v3"

# Plage matinale : 06h00–10h00 UTC+0 (Dakar, pas de décalage horaire)
MATINALE_START_H = 6
MATINALE_END_H = 10


def _get(endpoint: str, **params) -> dict:
    params["key"] = API_KEY
    resp = requests.get(f"{BASE}/{endpoint}", params=params, timeout=15)
    resp.raise_for_status()
    return resp.json()


def resolve_channel(handle: str | None, channel_id: str | None) -> tuple[str, str]:
    """
    Returns (channel_id, uploads_playlist_id).
    Accepts either a @handle or a direct channel_id.
    """
    if channel_id:
        data = _get("channels", id=channel_id, part="contentDetails")
    elif handle:
        # handles start with @
        clean = handle.lstrip("@")
        data = _get("channels", forHandle=clean, part="contentDetails")
    else:
        raise ValueError("Provide handle or channel_id")

    items = data.get("items", [])
    if not items:
        raise LookupError(f"Chaîne introuvable : handle={handle} id={channel_id}")

    item = items[0]
    resolved_id = item["id"]
    playlist_id = item["contentDetails"]["relatedPlaylists"]["uploads"]
    return resolved_id, playlist_id


def _parse_duration(iso: str) -> int | None:
    """ISO 8601 duration → secondes. Ex: PT1H23M45S → 5025."""
    m = re.match(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", iso or "")
    if not m:
        return None
    h, mn, s = (int(x or 0) for x in m.groups())
    return h * 3600 + mn * 60 + s


def _is_matinale(published_at: str) -> bool:
    """True si la vidéo a été publiée entre 06h et 10h UTC."""
    dt = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
    return MATINALE_START_H <= dt.hour < MATINALE_END_H


def fetch_recent_videos(
    playlist_id: str,
    since: datetime,
) -> Iterator[dict]:
    """
    Génère les vidéos publiées après `since` dans la playlist.
    Chaque dict : youtube_video_id, title, published_at, duration_seconds.
    """
    page_token = None
    since_str = since.isoformat()

    while True:
        params = dict(
            playlistId=playlist_id,
            part="snippet",
            maxResults=50,
        )
        if page_token:
            params["pageToken"] = page_token

        data = _get("playlistItems", **params)

        video_ids = []
        snippet_map = {}
        for item in data.get("items", []):
            sn = item["snippet"]
            vid = sn["resourceId"]["videoId"]
            pub = sn.get("publishedAt", "")

            # Arrêt si on dépasse la fenêtre temporelle
            if pub < since_str:
                return

            video_ids.append(vid)
            snippet_map[vid] = {"title": sn.get("title", ""), "published_at": pub}

        # Récupère durée en un seul appel (videos.list)
        if video_ids:
            vdata = _get("videos", id=",".join(video_ids), part="contentDetails")
            durations = {
                v["id"]: _parse_duration(v["contentDetails"].get("duration"))
                for v in vdata.get("items", [])
            }
            for vid in video_ids:
                sn = snippet_map[vid]
                yield {
                    "youtube_video_id": vid,
                    "title": sn["title"],
                    "published_at": sn["published_at"],
                    "duration_seconds": durations.get(vid),
                }

        page_token = data.get("nextPageToken")
        if not page_token:
            break


def fetch_video_stats(video_ids: list[str]) -> dict[str, dict]:
    """
    Retourne {video_id: {view_count, like_count, comment_count}}
    pour une liste de video_ids (max 50 par appel).
    """
    result = {}
    for i in range(0, len(video_ids), 50):
        batch = video_ids[i:i + 50]
        data = _get("videos", id=",".join(batch), part="statistics")
        for item in data.get("items", []):
            s = item.get("statistics", {})
            result[item["id"]] = {
                "view_count": int(s.get("viewCount", 0)),
                "like_count": int(s.get("likeCount", 0)),
                "comment_count": int(s.get("commentCount", 0)),
            }
    return result


def is_matinale(published_at: str) -> bool:
    return _is_matinale(published_at)
